'use client';
import { useState } from 'react';

function adminFetch(endpoint: string) {
  const token = typeof window !== 'undefined' ? localStorage.getItem('bc_admin_token') : '';
  return fetch(`${process.env.NEXT_PUBLIC_API_URL}${endpoint}`, {
    headers: { Authorization: `Bearer ${token}` },
  }).then((r) => r.json()).then((d) => d.data ?? d);
}

import { useQuery } from '@tanstack/react-query';
import { Search } from 'lucide-react';

export default function AdminUsersPage() {
  const [search, setSearch] = useState('');

  const { data } = useQuery<any>({
    queryKey: ['admin-users'],
    queryFn: () => adminFetch('/auth/me'),
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">User Management</h1>
          <p className="text-muted text-sm">Registered customer accounts</p>
        </div>
      </div>
      <div className="card p-8 text-center">
        <p className="text-4xl mb-4">👤</p>
        <h3 className="text-lg font-semibold text-white mb-2">User Management</h3>
        <p className="text-muted text-sm max-w-sm mx-auto">Full user search and management available via API. Connect a dedicated user listing endpoint for production use.</p>
        <div className="mt-6 p-4 rounded-xl text-left" style={{ background: 'var(--color-brand-subtle)', border: '1px solid rgba(48,126,242,0.25)' }}>
          <p className="text-xs font-mono text-muted">GET /api/auth/me (authenticated user info)</p>
          <p className="text-xs font-mono text-muted mt-1">Admin can query user accounts via the backend API</p>
        </div>
      </div>
    </div>
  );
}
