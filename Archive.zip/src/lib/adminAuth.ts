'use client';

export interface AdminSession {
  id: string;
  name: string;
  email: string;
  role: 'SYSTEM_ADMIN' | 'STORE_MANAGER' | 'REPORT_VIEWER';
  storeId?: string | null;
  storeName?: string | null;
  storeCity?: string | null;
}

export function getAdminSession(): AdminSession | null {
  if (typeof window === 'undefined') return null;
  const raw = localStorage.getItem('bc_admin');
  if (!raw) return null;
  try {
    return JSON.parse(raw) as AdminSession;
  } catch {
    return null;
  }
}

export function isSuperAdmin(admin: AdminSession | null): boolean {
  return admin?.role === 'SYSTEM_ADMIN';
}

export function isBranchAdmin(admin: AdminSession | null): boolean {
  return admin?.role === 'STORE_MANAGER';
}

export function adminRoleLabel(role?: string): string {
  if (role === 'SYSTEM_ADMIN') return 'Super Admin';
  if (role === 'STORE_MANAGER') return 'Branch Admin';
  if (role === 'REPORT_VIEWER') return 'Report Viewer';
  return role ?? 'Admin';
}
