'use client';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, Minus } from 'lucide-react';
import { useCartStore, type SugarLevel, type IceLevel, type ProductSize } from '@/store/cartStore';
import type { Product, Topping } from '@/types';
import TagBadge from '@/components/ui/TagBadge';
import toast from 'react-hot-toast';

interface Props {
  product: Product;
  fulfillmentStore?: { id: string; name: string; distanceKm?: number } | null;
  onClose: () => void;
}

const SIZES: { value: ProductSize; label: string; extra: number }[] = [
  { value: 'REGULAR', label: 'Regular', extra: 0 },
  { value: 'LARGE', label: 'Large', extra: 100 },
];

const SUGAR_LEVELS: { value: SugarLevel; label: string }[] = [
  { value: 'ZERO', label: '0%' },
  { value: 'TWENTY_FIVE', label: '25%' },
  { value: 'FIFTY', label: '50%' },
  { value: 'SEVENTY_FIVE', label: '75%' },
  { value: 'HUNDRED', label: '100%' },
];

const ICE_LEVELS: { value: IceLevel; label: string }[] = [
  { value: 'NO_ICE', label: 'No Ice' },
  { value: 'LESS_ICE', label: 'Less Ice' },
  { value: 'REGULAR', label: 'Regular' },
];

export default function ProductDrawer({ product, fulfillmentStore, onClose }: Props) {
  const [size, setSize] = useState<ProductSize>('REGULAR');
  const [sugar, setSugar] = useState<SugarLevel>('HUNDRED');
  const [ice, setIce] = useState<IceLevel>('REGULAR');
  const [selectedToppings, setSelectedToppings] = useState<Topping[]>([]);
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore((s) => s.addItem);

  const availableToppings = product.toppings.map((pt) => pt.topping).filter((t) => t.isAvailable);

  function toggleTopping(t: Topping) {
    setSelectedToppings((prev) =>
      prev.find((x) => x.id === t.id)
        ? prev.filter((x) => x.id !== t.id)
        : [...prev, t]
    );
  }

  function calcPrice() {
    let p = product.basePrice;
    if (size === 'LARGE') p += 100;
    p += selectedToppings.reduce((s, t) => s + t.extraPrice, 0);
    return p;
  }

  function addToCart() {
    addItem({
      product,
      size,
      sugarLevel: sugar,
      iceLevel: ice,
      toppings: selectedToppings,
      quantity,
      unitPrice: calcPrice(),
      fulfillmentStore: fulfillmentStore
        ? {
            id: fulfillmentStore.id,
            name: fulfillmentStore.name,
            distanceKm: fulfillmentStore.distanceKm,
          }
        : undefined,
    });
    const branchNote = fulfillmentStore
      ? ` from ${fulfillmentStore.name.replace('Bing Chun - ', '')}`
      : '';
    toast.success(`${product.name} added to your cup${branchNote}! 🧋`);
    onClose();
  }

  const unitPrice = calcPrice();

  return (
    <>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50"
        style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)' }}
        onClick={onClose}
      />

      {/* Drawer */}
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', stiffness: 300, damping: 35 }}
        className="fixed right-0 top-0 bottom-0 z-50 flex flex-col"
        style={{
          width: '100%',
          maxWidth: '480px',
          background: 'var(--color-navy-card)',
          borderLeft: '1px solid var(--color-navy-border)',
          boxShadow: '-8px 0 40px rgba(0,0,0,0.4)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-navy-border">
          <h2 className="text-lg font-bold text-fg">Customise Order</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-navy-light transition-colors">
            <X size={18} className="text-muted" />
          </button>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* Product info */}
          <div className="flex gap-4 items-start">
            <div className="w-20 h-20 rounded-2xl overflow-hidden flex items-center justify-center shrink-0 bg-brand-subtle">
              {product.imageUrl ? (
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-4xl">🧋</span>
              )}
            </div>
            <div>
              {product.tag && <TagBadge tag={product.tag} />}
              <h3 className="text-fg font-bold mt-1">{product.name}</h3>
              <p className="text-muted text-xs mt-1">{product.description}</p>
              {fulfillmentStore && (
                <p className="text-amber-400 text-xs mt-2 font-medium">
                  📍 Fulfilled from {fulfillmentStore.name.replace('Bing Chun - ', '')}
                  {fulfillmentStore.distanceKm != null ? ` · ${fulfillmentStore.distanceKm} km` : ''}
                </p>
              )}
            </div>
          </div>

          {/* Size */}
          <div>
            <p className="text-sm font-semibold text-fg mb-3">Size</p>
            <div className="grid grid-cols-2 gap-3">
              {SIZES.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setSize(s.value)}
                  className={`p-3 rounded-xl border text-sm font-medium transition-all ${
                    size === s.value
                      ? 'chip-active border-brand'
                      : 'border-navy-border text-muted hover:border-brand hover:text-fg'
                  }`}
                >
                  {s.label}
                  {s.extra > 0 && <span className="text-brand ml-1">+{s.extra}</span>}
                </button>
              ))}
            </div>
          </div>

          {/* Sugar */}
          <div>
            <p className="text-sm font-semibold text-fg mb-3">Sugar Level</p>
            <div className="flex gap-2 flex-wrap">
              {SUGAR_LEVELS.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setSugar(s.value)}
                  className={`chip ${sugar === s.value ? 'chip-active' : ''}`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Ice */}
          <div>
            <p className="text-sm font-semibold text-fg mb-3">Ice Level</p>
            <div className="flex gap-2">
              {ICE_LEVELS.map((l) => (
                <button
                  key={l.value}
                  onClick={() => setIce(l.value)}
                  className={`chip flex-1 ${ice === l.value ? 'chip-active' : ''}`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>

          {/* Toppings */}
          {availableToppings.length > 0 && (
            <div>
              <p className="text-sm font-semibold text-fg mb-3">Add Toppings</p>
              <div className="space-y-2">
                {availableToppings.map((t) => {
                  const selected = selectedToppings.find((x) => x.id === t.id);
                  return (
                    <button
                      key={t.id}
                      onClick={() => toggleTopping(t)}
                      className={`w-full flex items-center justify-between p-3 rounded-xl border text-sm transition-all ${
                        selected
                          ? 'border-brand bg-brand-subtle text-fg'
                          : 'border-navy-border text-muted hover:border-brand hover:text-fg'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className={`w-4 h-4 rounded border flex items-center justify-center text-xs ${
                          selected ? 'border-brand bg-brand text-white' : 'border-navy-border'
                        }`}>
                          {selected && '✓'}
                        </span>
                        {t.name}
                      </span>
                      <span className="text-brand font-medium">+LKR {t.extraPrice}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quantity */}
          <div>
            <p className="text-sm font-semibold text-fg mb-3">Quantity</p>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-10 h-10 rounded-full border border-navy-border flex items-center justify-center hover:border-brand transition-colors"
              >
                <Minus size={16} />
              </button>
              <span className="text-xl font-bold text-fg w-8 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                className="w-10 h-10 rounded-full border border-navy-border flex items-center justify-center hover:border-brand transition-colors"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-5 border-t border-navy-border">
          <div className="flex items-center justify-between mb-4">
            <span className="text-muted text-sm">Total</span>
            <span className="text-brand font-bold text-xl">LKR {(unitPrice * quantity).toLocaleString()}</span>
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={addToCart}
            className="btn-primary w-full py-4 text-base"
          >
            Add to Cart · LKR {(unitPrice * quantity).toLocaleString()}
          </motion.button>
        </div>
      </motion.div>
    </>
  );
}
